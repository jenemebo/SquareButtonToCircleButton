//
//  ViewController.swift
//  SquarebuttonToCircleButton
//
//  Created by Chunhua Huang on 2017/10/27.
//  Copyright © 2017年 HAS Tech. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // FB登入按鈕
    @IBOutlet weak var loginByFB: UIButton!
    
    // Google+登入按鈕
    @IBOutlet weak var loginByGooglePlus: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
      NSTimer.scheduledTimerWithTimeInterval(3, target: self, selector: #selector(ViewController.changeButton), userInfo: nil, repeats: false);
    }
    
    func changeButton()
    {
        // 鍵盤跑出來後 設定loginByFB的圖
        var fbButtonImage: UIImage!
        
        fbButtonImage = UIImage(named: "ic__FB_1.png")
        
        self.loginByFB.setImage(fbButtonImage, forState: .Normal)
        
        // 鍵盤跑出來後 設定loginByGooglePlus的圖
        var googleButtonImage: UIImage!
        
        googleButtonImage = UIImage(named: "ic__G+_1.png")
        
        self.loginByGooglePlus.setImage(googleButtonImage, forState: .Normal)
        
        

        // 縮小按鈕的動畫 3.0 = 執行速度 數字越大跑得越慢 ; 這邊是展示縮小放大的動畫
//                UIView.animateWithDuration(3.0 ,
//                                           animations:
//                    {
//                                            // 縮放尺寸
//                                            self.loginByFB.transform = CGAffineTransformMakeScale(0.6, 0.6)
//                                            self.loginByGooglePlus.transform = CGAffineTransformMakeScale(0.6, 0.6)
//                    },
//                                           completion: { finish in
//                                            UIView.animateWithDuration(0.6){
//                                                self.loginByFB.transform = CGAffineTransformIdentity
//                                                self.loginByGooglePlus.transform = CGAffineTransformIdentity
//                                            }
//                })
        
        
        
        
        // 讓按鈕從長方形變成圓形的動畫 -- 用來將FB和Google+按鈕變成圓形的
        UIView.animateWithDuration(3.0 ,
                                   animations:
            {
             
                // 下面程式如果註解掉的話會直接執行completion的地方
                // 重新定義 loginByFB 的位置與frame
//                self.loginByFB.frame = CGRectMake(self.loginByFB.frame.origin.x - 60, self.loginByFB.frame.origin.y - 160, self.loginByFB.frame.size.width, self.loginByFB.frame.size.height)
//                
//                self.loginByFB.layer.cornerRadius = 0.5 * self.loginByFB.bounds.size.width
//                
//                
//                self.loginByFB.layer.borderWidth = 1.0
//                self.loginByFB.clipsToBounds = true
//                
//                
//                // 重新定義 loginByGooglePlus 的位置與frame
//                self.loginByGooglePlus.frame = CGRectMake(self.loginByFB.frame.origin.x - 60, self.loginByGooglePlus.frame.origin.y - 160, self.loginByGooglePlus.frame.size.width, self.loginByFB.frame.size.height)
//                
//                self.loginByGooglePlus.layer.cornerRadius = 0.5 * self.loginByFB.bounds.size.width
//                
//                
//                self.loginByGooglePlus.layer.borderWidth = 1.0
//                self.loginByGooglePlus.clipsToBounds = true
                
                
                
                
            },
                                   completion: { finish in
                                    UIView.animateWithDuration(3.0){
                                        
                                        
                                        // 重新定義 loginByFB 的位置與frame
                                        self.loginByFB.imageView?.image = fbButtonImage
                                        
                                        self.loginByFB.bounds.size.width = 60
                                        self.loginByFB.bounds.size.height = 60
                                        
                                        self.loginByFB.frame = CGRectMake(self.loginByFB.frame.origin.x - 70, self.loginByFB.frame.origin.y - 145, self.loginByFB.frame.size.width, self.loginByFB.frame.size.height)
                                        
                                        self.loginByFB.layer.cornerRadius = 0.5 * self.loginByFB.bounds.size.width
                                        
                                        
                                        self.loginByFB.layer.borderWidth = 1.0
                                        self.loginByFB.clipsToBounds = true
                                        
                                        
                                        
                                        // 重新定義 loginByGooglePlus 的位置與frame
                                        self.loginByGooglePlus.imageView?.image = fbButtonImage
                                        
                                        self.loginByGooglePlus.bounds.size.width = 60
                                        self.loginByGooglePlus.bounds.size.height = 60
                                        
                                        self.loginByGooglePlus.frame = CGRectMake(self.loginByGooglePlus.frame.origin.x + 60, self.loginByGooglePlus.frame.origin.y - 200, self.loginByGooglePlus.frame.size.width, self.loginByGooglePlus.frame.size.height)
                                        
                                        self.loginByGooglePlus.layer.cornerRadius = 0.5 * self.loginByGooglePlus.bounds.size.width
                                        
                                        
                                        self.loginByGooglePlus.layer.borderWidth = 1.0
                                        self.loginByGooglePlus.clipsToBounds = true
                                    }
        })
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

